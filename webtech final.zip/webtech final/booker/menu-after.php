
      <nav class = "navbar">
          <a href = "index.php" class = "navbar-brand">BooKer.</a>
          <button type = "button" class = "navbar-toggler">
            <i class = "fas fa-bars"></i>
          </button>
          <div class = "navbar-collapse">
            <ul>
              <li><a href = "./index.php">Home</a></li>
              <li><a href = "./bookStore.php">BookStore</a></li>
              <li><a href = "login.php">Logout</a></li>
            </ul>
          </div>

          <div class = "cart">
            <button type = "button" id = "cart-btn">
              <i class = "fas fa-shopping-cart"></i>
              <span id = "cart-count-info"></span>
            </button>
            
            <div class = "cart-container">
              <div class = "cart-list">
                
              </div>
              <div class = "cart-total">
                <h3>Total: $</h3>
                <span id = "cart-total-value"></span>
                <div class="confirm">
                  <a href="confirm.php">Confirm</a>
                </div>
              </div>
              
            </div>
          </div>
        </nav>


      
