<?php
  include 'admin/db/e-book_store.sql';

  // $hostname = "http://localhost/shbs";
  $hostname = "http://localhost/e-book_store";
    
?>
