<?php include('header.php') ?>
<body>
<?php include('menu-after.php') ?>

  <section class = "products">
      <div class = "container">
        <h2>Our Products</h2>
        <div class = "product-list">
         
          </div>
          
        </div>
      </div>
  </section>   
  
<?php include('footer.php') ?>
