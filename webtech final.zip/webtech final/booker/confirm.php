<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title>BooKer.</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./CSS/menu.css">
    <link rel="stylesheet" href="./CSS/payment-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.js"></script>
    
  </head>
  <body>




<nav class = "navbar">
          <a href = "index.php" class = "navbar-brand">BooKer.</a>
          <button type = "button" class = "navbar-toggler">
            <i class = "fas fa-bars"></i>
          </button>
          <div class = "navbar-collapse">
            <ul>
              <li><a href = "./index.php">Home</a></li>
              <li><a href = "./bookStore.php">BookStore</a></li>
                <li><a href = "login.php">Logout</a></li>
            </ul>
          </div>

          <div class = "cart">
            <button type = "button" id = "cart-btn">
              <i class = "fas fa-shopping-cart"></i>
              <span id = "cart-count-info"></span>
            </button>
            
            <div class = "cart-container">
              <div class = "cart-list">
                
              </div>

              <div class = "cart-total">
                <h3>Total: $</h3>
                <span id = "cart-total-value"></span>
                <!-- <div class="confirm">
                <a href="confirm.php">Confirm</a>
              </div> -->
              </div>
              
            </div>
          </div>
        </nav>

    
    <section class = "product">
   
    <div class="container">
   
    <div class="product-list" style="visibility:hidden; display:none;">
    </div>
    </section>

    <h1 style=" text-align:center; color:black; padding-top:5% ;">Payment</h1>




    <div class="form"  >
   <div class="row">
    <div class="col-75">
        <div class="container">
            <form id="validate"  action="customer.php" method="POST">
                <div class="row">
                    <div class="col-50">
                        <h3>Billing Address</h3>
                        <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                        <input type="text" id="fname" name="name" placeholder="Anindha DebNath" required >
                        <label for="email"><i class="fa fa-envelope"></i> Email</label>
                        <input type="text" id="email" name="email" placeholder="nanindha@gmail.com" required >
                        <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                        <input type="text" id="adr" name="address" placeholder="H-50,R-10,Block:A,Bashundhara,Vatara" required >
                        <label for="city"><i class="fa fa-institution"></i> City</label>
                        <input type="text" id="city" name="city" placeholder="Dhaka" required >

                        <div class="row">
                            <div class="col-50">
                                <label for="state">Orede Number</label>
                                <input type="text" id="OrderNumber" name="ordernumber" placeholder="Book 1, Book 2, Book 2"required >
                            </div>
                            <div class="col-50">
                                <label for="zip">Price</label>
                                <input type="text" id="price" name="price" placeholder="100"required>
                            </div>
                        </div>
                    </div>

                    <div class="col-50">
                        <h3>Payment</h3>
                        <label for="fname">Accepted Cards</label>
                        <div class="icon-container">
                            <i class="fa fa-cc-visa" style="color:navy;"></i>
                            <i class="fa fa-cc-amex" style="color:blue;"></i>
                            <i class="fa fa-cc-mastercard" style="color:red;"></i>
                            <i class="fa fa-cc-discover" style="color:orange;"></i>
                        </div>

                        <label for="cname">Name on Card</label>
                        <input type="text" id="cname" name="cardname" placeholder="ANINDHA DEBNATH"required >
                        <label for="ccnum">Credit card number</label>
                        <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444"required >
                        <label for="expmonth">Exp Month</label>
                        <input type="text" id="expmonth" name="expmonth" placeholder="JUN"required >
                        <div class="row">
                            <div class="col-50">
                                <label for="expyear">Exp Year</label>
                                <input type="text" id="expyear" name="expyear" placeholder="2021"required>
                            </div>
                            <div class="col-50">
                                <label for="cvv">CVV</label>
                                <input type="text" id="cvv" name="cvv" placeholder="750"required>
                            </div>
                        </div>
                    </div>
                </div>
                <label>
                <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
                </label>
                <input type="submit" value="Continue to checkout" class="btn">
            </form>
        </div>
    </div>
        
    </div>
    
</div>
      


    
    <script src="./menu.js"></script>

  </body>
  </html>