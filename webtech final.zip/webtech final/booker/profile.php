<?php include ('header.php')?>

<link rel="stylesheet" href="./CSS/profile.css">
<body>

<?php include ('menu.php')?> 


    <form action="customer.php" method="post" enctype=multipart/form-data>
    <div class="wrapper">
    
    <div class="left">
    </div>
    <div class="right">
        <div class="info">
            <h3>Information</h3>
            <div class="info_data">
                 <div class="data">
                    <h4>Name</h4>
                    <p><?php echo ['name']?></p>
                 </div>
                 <div class="data">
                   <h4>Email</h4>
                    <p><?php echo $row['email']?></p>
              </div>
            </div>
        </div>
      
      <div class="projects">
            <h3>Address</h3>
            <div class="projects_data">
                 <div class="data">
                    <h4>Present Address</h4>
                    <p><?php echo $row['address']?></p>
                 </div>
                 <div class="data">
                   <h4>City</h4>
                    <p><?php echo $row['city']?></p>
              </div>
            </div>
        </div>
        
        <!-- <div class="social_media">
            <ul>
              <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
      </div> -->
    </div>
   
</div>
</form>

<?php include('footer.php')  ?>










