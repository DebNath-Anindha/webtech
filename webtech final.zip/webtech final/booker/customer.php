<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $ordernumber = $_POST['ordernumber'];
    $price = $_POST['price'];
    $cardname = $_POST['cardname'];
    $cardnumber = $_POST['cardnumber'];
    $expmonth = $_POST['expmonth'];
    $expyear = $_POST['expyear'];
    $cvv = $_POST['cvv'];
    




    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bookdb";

    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO customer(name, email, address, city, ordernumber, price, cardname , cardnumber, expmonth ,expyear,cvv )
VALUES ('$name', '$email', '$address',' $city', '$ordernumber', '$price',' $cardname' , '$cardnumber', '$expmonth' ,'$expyear','$cvv')";

    if ($conn->query($sql) === true) {
        // echo "New record created successfully";
        echo '<script>alert("Payment Done Succesfully")</script>';
        header("refresh: 0; url=bookStore.php");
        

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();

    
}
?>



