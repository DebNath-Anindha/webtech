
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
     <!-- <link rel="stylesheet" href="./CSS/owl.carousel.css">
     <link rel="stylesheet" href="./css/owl.theme.default.css"> -->
     <link rel="stylesheet" href="https://unpkg.com/flickity@2.0.11/dist/flickity.min.css">
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    
    
    
   
   
    <link rel="stylesheet" href="./CSS/container3.css">
    <link rel="stylesheet" href="./CSS/anounce2.css">
    <link rel="stylesheet" href="./CSS/anounce3.css">
    <link rel="stylesheet" href="./CSS/footer.css">
    <link rel="stylesheet" href="./CSS/Responsive.css">
    <link rel="stylesheet" href="./CSS/bootstrap.css">
    <link rel="stylesheet" href="./CSS/all.css">
    <link rel="stylesheet" href="./CSS/multi-carosel-1.css">
    <link rel="stylesheet" href="./CSS/multi-carosel-2.css">
    <link rel="stylesheet" href="./CSS/profile.css">
    <link rel="stylesheet" href="./CSS/loader.css">
    <link rel="stylesheet" href="./CSS/menu.css">
    <link rel="stylesheet" href="./CSS/style.css">
<!-- <Script type="text/javascript" src="./JS/loader.js">
</Script> -->
<Script type="text/javascript" src="./Js/bootstrap.bundle.js">
</Script>





<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
  integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
  integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>

</script>
<script src="https://unpkg.com/flickity@2.0.11/dist/flickity.pkgd.min.js">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
  integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
</script>
<Script type="text/javascript" src="./Js/main.js"> </Script>
<Script type="text/javascript" src="./Js/all.js"> </Script>
    <title>BOOKER</title>
</head>



